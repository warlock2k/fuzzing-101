#include "config.h"
#include "i18n.h"

#include <stdio.h>

int main(int argc, char *argv[])
{
  puts(LOCALEDIR);
  puts("\n");
  return 0;
}
